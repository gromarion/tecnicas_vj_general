package animator;

public interface Function {
	public double apply(double x);
}
